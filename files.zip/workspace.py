"""
Workspace widgets for PTC.

The workspace is the main content area that changes based on context:
- WelcomeWidget: Shown when no project is selected
- WorkspaceWidget: Shown when working with a project
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QScrollArea, QTextEdit,
    QLineEdit, QSizePolicy
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont

from core.project import Project


class WelcomeWidget(QWidget):
    """
    Welcome screen shown when no project is selected.
    
    The first impression - friendly, inviting, not intimidating.
    """
    
    new_clicked = pyqtSignal()
    adopt_clicked = pyqtSignal()
    
    def __init__(self):
        super().__init__()
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(60, 60, 60, 60)
        
        # Center content vertically
        layout.addStretch(1)
        
        # Main message
        title = QLabel("Ready to ship something?")
        title.setObjectName("welcomeTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        subtitle = QLabel(
            "Pick a project from the sidebar, or start fresh."
        )
        subtitle.setObjectName("welcomeSubtitle")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)
        
        layout.addSpacing(40)
        
        # Action buttons (centered)
        btn_container = QWidget()
        btn_layout = QHBoxLayout(btn_container)
        btn_layout.setSpacing(16)
        
        btn_layout.addStretch()
        
        btn_new = QPushButton("Start New Project")
        btn_new.setObjectName("welcomeButtonPrimary")
        btn_new.clicked.connect(self.new_clicked.emit)
        btn_layout.addWidget(btn_new)
        
        btn_adopt = QPushButton("Adopt Existing Script")
        btn_adopt.setObjectName("welcomeButtonSecondary")
        btn_adopt.clicked.connect(self.adopt_clicked.emit)
        btn_layout.addWidget(btn_adopt)
        
        btn_layout.addStretch()
        
        layout.addWidget(btn_container)
        
        # Fun hint at the bottom
        layout.addStretch(2)
        
        hint = QLabel(
            "💡 Got a script in Downloads? The Adopt button is your friend."
        )
        hint.setObjectName("welcomeHint")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(hint)
        
        layout.addStretch(1)
        
        self.apply_styles()
    
    def apply_styles(self):
        self.setStyleSheet("""
            WelcomeWidget {
                background-color: #1a1a2e;
            }
            
            #welcomeTitle {
                color: #ffffff;
                font-size: 28px;
                font-weight: 600;
            }
            
            #welcomeSubtitle {
                color: #888;
                font-size: 16px;
                margin-top: 8px;
            }
            
            #welcomeButtonPrimary {
                background-color: #4a9eff;
                color: white;
                border: none;
                padding: 14px 28px;
                border-radius: 8px;
                font-size: 15px;
                font-weight: 500;
            }
            
            #welcomeButtonPrimary:hover {
                background-color: #5aafff;
            }
            
            #welcomeButtonPrimary:pressed {
                background-color: #3a8eef;
            }
            
            #welcomeButtonSecondary {
                background-color: #2a2a4e;
                color: #c4c4c4;
                border: 1px solid #3a3a5e;
                padding: 14px 28px;
                border-radius: 8px;
                font-size: 15px;
            }
            
            #welcomeButtonSecondary:hover {
                background-color: #3a3a5e;
                color: #ffffff;
            }
            
            #welcomeHint {
                color: #666;
                font-size: 13px;
            }
        """)


class WorkspaceWidget(QWidget):
    """
    Project workspace - shown when a project is selected.
    
    Contains:
    - Project header with name and status
    - Big action buttons (Launch, Save Version)
    - Version timeline
    """
    
    project_changed = pyqtSignal()  # Emitted when project state changes
    
    def __init__(self):
        super().__init__()
        self.project: Project | None = None
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 24, 32, 24)
        layout.setSpacing(24)
        
        # === HEADER ===
        header = QWidget()
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(0, 0, 0, 0)
        
        # Project info (left side)
        info = QWidget()
        info_layout = QVBoxLayout(info)
        info_layout.setContentsMargins(0, 0, 0, 0)
        info_layout.setSpacing(4)
        
        self.project_name = QLabel("No Project Selected")
        self.project_name.setObjectName("projectName")
        info_layout.addWidget(self.project_name)
        
        self.project_path = QLabel("")
        self.project_path.setObjectName("projectPath")
        info_layout.addWidget(self.project_path)
        
        header_layout.addWidget(info)
        header_layout.addStretch()
        
        # Status indicator (right side)
        self.status_label = QLabel("")
        self.status_label.setObjectName("statusLabel")
        header_layout.addWidget(self.status_label)
        
        layout.addWidget(header)
        
        # === BIG ACTION BUTTONS ===
        actions = QWidget()
        actions_layout = QHBoxLayout(actions)
        actions_layout.setContentsMargins(0, 0, 0, 0)
        actions_layout.setSpacing(16)
        
        self.btn_launch = QPushButton("▶  Launch")
        self.btn_launch.setObjectName("actionButtonPrimary")
        self.btn_launch.clicked.connect(self.on_launch)
        actions_layout.addWidget(self.btn_launch)
        
        self.btn_save = QPushButton("💾  Save Version")
        self.btn_save.setObjectName("actionButtonSecondary")
        self.btn_save.clicked.connect(self.on_save_version)
        actions_layout.addWidget(self.btn_save)
        
        actions_layout.addStretch()
        
        layout.addWidget(actions)
        
        # === VERSION TIMELINE ===
        timeline_header = QLabel("Version History")
        timeline_header.setObjectName("sectionHeader")
        layout.addWidget(timeline_header)
        
        self.timeline = QScrollArea()
        self.timeline.setObjectName("timeline")
        self.timeline.setWidgetResizable(True)
        self.timeline.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        
        self.timeline_content = QWidget()
        self.timeline_layout = QVBoxLayout(self.timeline_content)
        self.timeline_layout.setContentsMargins(0, 0, 0, 0)
        self.timeline_layout.setSpacing(8)
        self.timeline_layout.addStretch()
        
        self.timeline.setWidget(self.timeline_content)
        layout.addWidget(self.timeline, 1)
        
        self.apply_styles()
    
    def set_project(self, project: Project):
        """Load a project into the workspace."""
        self.project = project
        self.refresh_ui()
    
    def refresh_ui(self):
        """Update all UI elements to reflect current project state."""
        if not self.project:
            return
        
        # Update header
        self.project_name.setText(self.project.name)
        self.project_path.setText(str(self.project.path))
        
        # Update status
        if self.project.has_unsaved_changes:
            self.status_label.setText("● Unsaved changes")
            self.status_label.setStyleSheet("color: #ffa500;")
        else:
            self.status_label.setText("✓ All saved")
            self.status_label.setStyleSheet("color: #4a9eff;")
        
        # Update timeline
        self.refresh_timeline()
    
    def refresh_timeline(self):
        """Reload the version history timeline."""
        # Clear existing items
        while self.timeline_layout.count() > 1:  # Keep the stretch
            item = self.timeline_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        if not self.project:
            return
        
        history = self.project.get_version_history()
        
        if not history:
            empty = QLabel("No versions yet. Click 'Save Version' to create your first snapshot.")
            empty.setObjectName("timelineEmpty")
            empty.setWordWrap(True)
            self.timeline_layout.insertWidget(0, empty)
            return
        
        for i, version in enumerate(history):
            item = VersionItem(
                message=version["message"],
                date=version["date"],
                hash=version["hash"],
                is_latest=(i == 0)
            )
            self.timeline_layout.insertWidget(self.timeline_layout.count() - 1, item)
    
    def on_launch(self):
        """Launch the project's main file."""
        if not self.project:
            return
        
        try:
            self.project.launch()
            # TODO: Show output in a panel
        except Exception as e:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.warning(
                self,
                "Launch Failed",
                f"Couldn't launch the project:\n\n{e}"
            )
    
    def on_save_version(self):
        """Save the current state as a new version."""
        if not self.project:
            return
        
        # TODO: Add optional message input dialog
        saved = self.project.save_version()
        
        if saved:
            self.refresh_ui()
            self.project_changed.emit()
        else:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.information(
                self,
                "Nothing to Save",
                "No changes detected since your last save.\n\n"
                "Keep working - I'll be here when you're ready."
            )
    
    def apply_styles(self):
        self.setStyleSheet("""
            WorkspaceWidget {
                background-color: #1a1a2e;
            }
            
            #projectName {
                color: #ffffff;
                font-size: 22px;
                font-weight: 600;
            }
            
            #projectPath {
                color: #666;
                font-size: 12px;
            }
            
            #statusLabel {
                font-size: 13px;
                padding: 6px 12px;
                border-radius: 4px;
                background-color: #2a2a4e;
            }
            
            #actionButtonPrimary {
                background-color: #2ecc71;
                color: white;
                border: none;
                padding: 16px 32px;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 500;
                min-width: 140px;
            }
            
            #actionButtonPrimary:hover {
                background-color: #3ddc81;
            }
            
            #actionButtonPrimary:pressed {
                background-color: #27ae60;
            }
            
            #actionButtonSecondary {
                background-color: #4a9eff;
                color: white;
                border: none;
                padding: 16px 32px;
                border-radius: 8px;
                font-size: 16px;
                font-weight: 500;
                min-width: 140px;
            }
            
            #actionButtonSecondary:hover {
                background-color: #5aafff;
            }
            
            #actionButtonSecondary:pressed {
                background-color: #3a8eef;
            }
            
            #sectionHeader {
                color: #888;
                font-size: 13px;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 1px;
            }
            
            #timeline {
                background-color: #16213e;
                border: 1px solid #0f3460;
                border-radius: 8px;
            }
            
            #timelineEmpty {
                color: #666;
                font-size: 13px;
                padding: 20px;
            }
        """)


class VersionItem(QFrame):
    """A single version in the timeline."""
    
    def __init__(self, message: str, date: str, hash: str, is_latest: bool = False):
        super().__init__()
        self.hash = hash
        
        self.setObjectName("versionItem")
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        
        # Indicator dot
        dot = QLabel("●" if is_latest else "○")
        dot.setObjectName("versionDot")
        dot.setStyleSheet(f"color: {'#4a9eff' if is_latest else '#444'};")
        layout.addWidget(dot)
        
        # Message and date
        info = QWidget()
        info_layout = QVBoxLayout(info)
        info_layout.setContentsMargins(0, 0, 0, 0)
        info_layout.setSpacing(2)
        
        msg_label = QLabel(message)
        msg_label.setObjectName("versionMessage")
        info_layout.addWidget(msg_label)
        
        # Format date nicely
        try:
            from datetime import datetime
            dt = datetime.fromisoformat(date.replace(" ", "T").split("+")[0])
            nice_date = dt.strftime("%b %d, %Y at %I:%M %p")
        except:
            nice_date = date
        
        date_label = QLabel(nice_date)
        date_label.setObjectName("versionDate")
        info_layout.addWidget(date_label)
        
        layout.addWidget(info, 1)
        
        # Short hash
        hash_label = QLabel(hash[:7])
        hash_label.setObjectName("versionHash")
        layout.addWidget(hash_label)
        
        self.setStyleSheet("""
            #versionItem {
                background-color: transparent;
                border-radius: 6px;
            }
            
            #versionItem:hover {
                background-color: #1a1a40;
            }
            
            #versionDot {
                font-size: 10px;
            }
            
            #versionMessage {
                color: #e8e8e8;
                font-size: 13px;
            }
            
            #versionDate {
                color: #666;
                font-size: 11px;
            }
            
            #versionHash {
                color: #555;
                font-size: 11px;
                font-family: monospace;
            }
        """)
