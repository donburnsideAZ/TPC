#!/usr/bin/env python3
"""
PTC - Pack Track Click
The packaging tool for people who just want to ship.

"I just want to hand someone an installer and say 'here, this works.'"
"""

import sys
from pathlib import Path

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont

from ui.main_window import MainWindow


def main():
    # Enable high DPI scaling
    app = QApplication(sys.argv)
    
    # Set application metadata
    app.setApplicationName("PTC")
    app.setApplicationDisplayName("PTC - Pack Track Click")
    app.setOrganizationName("PTC")
    
    # Set a clean, friendly default font
    font = QFont("SF Pro Display", 13)
    font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    app.setFont(font)
    
    # Create and show the main window
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
