"""
Project model for PTC.

A project is a Python codebase that PTC manages. Projects have:
- A location on disk (the project folder)
- A .ptc/ folder containing config and state
- An invisible git repo for version tracking
- Metadata about what we're building

The user never sees .ptc/ or .git/ - they just see their code.
"""

import json
import subprocess
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field, asdict
from typing import Optional


# Default location for new projects
DEFAULT_PROJECTS_ROOT = Path.home() / "Documents" / "PTC Projects"


@dataclass
class Project:
    """Represents a PTC-managed project."""
    
    name: str
    path: Path
    main_file: str = "main.py"
    description: str = ""
    python_version: str = "3.11"
    created: str = field(default_factory=lambda: datetime.now().isoformat())
    github_repo: Optional[str] = None
    
    # Runtime state (not persisted)
    _has_unsaved_changes: bool = field(default=False, repr=False)
    
    @property
    def ptc_dir(self) -> Path:
        """The hidden .ptc config directory."""
        return self.path / ".ptc"
    
    @property
    def config_file(self) -> Path:
        """The project.json config file."""
        return self.ptc_dir / "project.json"
    
    @property
    def main_file_path(self) -> Path:
        """Full path to the main Python file."""
        return self.path / self.main_file
    
    @property
    def has_unsaved_changes(self) -> bool:
        """Check if there are uncommitted changes."""
        if not (self.path / ".git").exists():
            return False
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=self.path,
                capture_output=True,
                text=True
            )
            return bool(result.stdout.strip())
        except Exception:
            return False
    
    def save_config(self) -> None:
        """Save project configuration to .ptc/project.json."""
        self.ptc_dir.mkdir(parents=True, exist_ok=True)
        
        # Only persist the config fields, not runtime state
        config = {
            "name": self.name,
            "main_file": self.main_file,
            "description": self.description,
            "python_version": self.python_version,
            "created": self.created,
            "github_repo": self.github_repo,
        }
        
        with open(self.config_file, "w") as f:
            json.dump(config, f, indent=2)
    
    @classmethod
    def load(cls, path: Path) -> "Project":
        """Load a project from a directory containing .ptc/project.json."""
        ptc_dir = path / ".ptc"
        config_file = ptc_dir / "project.json"
        
        if not config_file.exists():
            raise ValueError(f"No PTC project found at {path}")
        
        with open(config_file) as f:
            config = json.load(f)
        
        return cls(
            name=config["name"],
            path=path,
            main_file=config.get("main_file", "main.py"),
            description=config.get("description", ""),
            python_version=config.get("python_version", "3.11"),
            created=config.get("created", datetime.now().isoformat()),
            github_repo=config.get("github_repo"),
        )
    
    @classmethod
    def create_new(
        cls,
        name: str,
        location: Optional[Path] = None,
        description: str = "",
        main_file: str = "main.py",
    ) -> "Project":
        """
        Create a new project from scratch.
        
        Sets up:
        - Project folder structure
        - .ptc/ config directory
        - Git repo (silently)
        - Starter main.py if none exists
        """
        if location is None:
            location = DEFAULT_PROJECTS_ROOT
        
        project_path = location / name
        project_path.mkdir(parents=True, exist_ok=True)
        
        # Create the project instance
        project = cls(
            name=name,
            path=project_path,
            main_file=main_file,
            description=description,
        )
        
        # Save config
        project.save_config()
        
        # Create starter main.py if it doesn't exist
        main_path = project_path / main_file
        if not main_path.exists():
            main_path.write_text(f'''#!/usr/bin/env python3
"""
{name}
{description if description else "A new project."}

Created with PTC - Pack Track Click
"""


def main():
    print("Hello from {name}!")


if __name__ == "__main__":
    main()
''')
        
        # Initialize git silently
        project._init_git()
        
        # Save first version
        project.save_version("Initial project setup")
        
        return project
    
    @classmethod
    def adopt(
        cls,
        source_file: Path,
        name: str,
        location: Optional[Path] = None,
        additional_files: Optional[list[Path]] = None,
        delete_original: bool = False,
    ) -> "Project":
        """
        Adopt an existing script into a proper PTC project.
        
        The rescue mission - take that Downloads folder script and
        give it a real home.
        """
        if location is None:
            location = DEFAULT_PROJECTS_ROOT
        
        project_path = location / name
        project_path.mkdir(parents=True, exist_ok=True)
        
        # Copy the main file
        import shutil
        dest_file = project_path / source_file.name
        shutil.copy2(source_file, dest_file)
        
        # Copy any additional files
        if additional_files:
            for f in additional_files:
                if f.is_file():
                    shutil.copy2(f, project_path / f.name)
                elif f.is_dir():
                    shutil.copytree(f, project_path / f.name)
        
        # Create the project
        project = cls(
            name=name,
            path=project_path,
            main_file=source_file.name,
            description=f"Adopted from {source_file.parent.name}",
        )
        
        # Save config
        project.save_config()
        
        # Initialize git
        project._init_git()
        
        # Save first version
        project.save_version(f"Adopted from {source_file}")
        
        # Optionally clean up the original
        if delete_original:
            source_file.unlink()
            if additional_files:
                for f in additional_files:
                    if f.exists():
                        if f.is_file():
                            f.unlink()
                        else:
                            shutil.rmtree(f)
        
        return project
    
    def _init_git(self) -> None:
        """Initialize a git repository silently."""
        git_dir = self.path / ".git"
        if git_dir.exists():
            return
        
        try:
            subprocess.run(
                ["git", "init"],
                cwd=self.path,
                capture_output=True,
                check=True
            )
            
            # Create a .gitignore
            gitignore = self.path / ".gitignore"
            if not gitignore.exists():
                gitignore.write_text("""# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
.venv/
ENV/

# PTC build outputs
dist/
build/
*.spec

# IDE
.idea/
.vscode/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db
""")
        except Exception as e:
            # Git init failed - not fatal, just means no version control
            print(f"Warning: Could not initialize git: {e}")
    
    def save_version(self, message: Optional[str] = None) -> bool:
        """
        Save the current state as a version (git commit).
        
        Returns True if a version was saved, False if nothing to save.
        """
        if message is None:
            message = f"Saved at {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        
        try:
            # Stage all changes
            subprocess.run(
                ["git", "add", "-A"],
                cwd=self.path,
                capture_output=True,
                check=True
            )
            
            # Check if there's anything to commit
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=self.path,
                capture_output=True,
                text=True
            )
            
            if not result.stdout.strip():
                return False  # Nothing to commit
            
            # Commit
            subprocess.run(
                ["git", "commit", "-m", message],
                cwd=self.path,
                capture_output=True,
                check=True
            )
            
            return True
            
        except Exception as e:
            print(f"Warning: Could not save version: {e}")
            return False
    
    def get_version_history(self) -> list[dict]:
        """Get the version history (git log) as a list of dicts."""
        try:
            result = subprocess.run(
                ["git", "log", "--pretty=format:%H|%s|%ai", "-n", "50"],
                cwd=self.path,
                capture_output=True,
                text=True,
                check=True
            )
            
            history = []
            for line in result.stdout.strip().split("\n"):
                if line:
                    parts = line.split("|", 2)
                    if len(parts) == 3:
                        history.append({
                            "hash": parts[0],
                            "message": parts[1],
                            "date": parts[2],
                        })
            
            return history
            
        except Exception:
            return []
    
    def launch(self) -> subprocess.Popen:
        """Launch the main Python file."""
        return subprocess.Popen(
            ["python3", self.main_file],
            cwd=self.path,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )


def find_ptc_projects(root: Optional[Path] = None) -> list[Project]:
    """
    Find all PTC projects under a given root directory.
    
    Searches for directories containing .ptc/project.json
    """
    if root is None:
        root = DEFAULT_PROJECTS_ROOT
    
    if not root.exists():
        return []
    
    projects = []
    
    # Look for .ptc directories
    for ptc_dir in root.rglob(".ptc"):
        if ptc_dir.is_dir() and (ptc_dir / "project.json").exists():
            try:
                project = Project.load(ptc_dir.parent)
                projects.append(project)
            except Exception:
                pass  # Skip invalid projects
    
    # Sort by name
    projects.sort(key=lambda p: p.name.lower())
    
    return projects
